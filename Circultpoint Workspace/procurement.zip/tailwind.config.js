
// remember to use module.exports instead of tailwind.config in production
tailwind.config = 
   {
      // Note: config only includes the used styles & variables of your selection
      content: ["./src/**/*.{html,vue,svelte,js,ts,jsx,tsx}"],
      theme: {
        extend: {
          fontFamily: {
            
          },
          fontSize: {
            
          },
          fontWeight: {
            
          },
          lineHeight: {
             
          },
          letterSpacing: {
             
          },
          borderRadius: {
              
          },
          colors: {
            
            'grey-color': 'rgba(56, 56, 56, 0.60)',
'primary-color': 'transparent',
'white-color': '#ffffff',
          },
          spacing: {
              
          },
          width: {
             
          },
          minWidth: {
             
          },
          maxWidth: {
             
          },
          height: {
             
          },
          minHeight: {
             
          },
          maxHeight: {
             
          }
        }
      }
    }

          